require('dotenv').config();
const { REST, Routes, SlashCommandBuilder } = require('discord.js');

// Replace with your actual IDs
const CLIENT_ID = '1425239136616583201';
const GUILD_ID = '1423370372358606920';

// Build the /ping command
const commands = [
  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Replies with Pong!')
    .toJSON()
];

// Send the command data to Discord
const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log('⏳ Refreshing slash commands...');

    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), {
      body: commands
    });

    console.log('✅ Successfully registered guild slash commands.');
  } catch (error) {
    console.error('❌ Error registering commands:', error);
  }
})();
